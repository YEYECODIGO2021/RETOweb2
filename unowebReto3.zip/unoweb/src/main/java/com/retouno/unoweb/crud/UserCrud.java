package com.retouno.unoweb.crud;

import java.util.Optional;
import com.retouno.unoweb.model.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserCrud extends MongoRepository<Usuario,Integer>{

    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findByEmailAndPassword(String email, String password);
    
    
}
