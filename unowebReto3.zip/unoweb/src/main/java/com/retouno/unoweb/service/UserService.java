package com.retouno.unoweb.service;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.model.Usuario;
import com.retouno.unoweb.repository.RepositoryUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private RepositoryUser repositoryUser;

     public Usuario saveNewUser(Usuario usuario){
         if(usuario.getId()==null){
             return usuario;
            } else {
            Optional<Usuario> consultar = repositoryUser.getUsuarioId(usuario.getId());
            if(consultar.isEmpty()){
            if(existeCorreo(usuario.getEmail())==false){
                return repositoryUser.save(usuario);
             }else{
                 return usuario;
             }      
            }else 
            {return usuario;}
        }   
    } 
     public List<Usuario> getListUsers(){
         return repositoryUser.getListUsuarios();
     }

     public Optional<Usuario> getUsuario(int id){
        return repositoryUser.getUsuarioId(id);

     }

     public boolean existeCorreo(String email){
         return repositoryUser.siExisteEmail(email);
     }

     public Usuario validarLoggin(String email, String password){
         Optional<Usuario> datoNuevo=repositoryUser.validarRegistros(email,password);
         if(datoNuevo.isEmpty()){
            return new Usuario();
         }else{
            return datoNuevo.get();
         }
     }
     public boolean deleteUser(int usuarioId){
         Boolean aBoolean = getUsuario(usuarioId).map(user->{
             repositoryUser.eliminarUser(user);
             return true;
         }).orElse(false);
         return aBoolean;
     }

     public Usuario actualizarUser(Usuario usuario){
         if(usuario.getId()!=null){
            Optional<Usuario> putUser = getUsuario(usuario.getId());
            if(!putUser.isEmpty()){
                if(usuario.getIdentification()!=null){putUser.get().setIdentification(usuario.getIdentification());}             
                if(usuario.getCellPhone()!=null){putUser.get().setCellPhone(usuario.getCellPhone());}
                if(usuario.getAddress()!=null){putUser.get().setAddress(usuario.getAddress());}
                if(usuario.getEmail()!=null){putUser.get().setEmail(usuario.getEmail());}
                if(usuario.getName()!=null){putUser.get().setName(usuario.getName());}
                if(usuario.getPassword()!=null){putUser.get().setPassword(usuario.getPassword());}
                if(usuario.getType()!=null){putUser.get().setType(usuario.getType());}
                if(usuario.getZone()!=null){putUser.get().setZone(usuario.getZone());}
            repositoryUser.actualizar(putUser.get());
            return putUser.get();
        }else{
            return usuario;
        }
    }else{
        return usuario;
    }
}

}
