package com.retouno.unoweb.controller;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.model.Usuario;
import com.retouno.unoweb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/user")
@CrossOrigin("*")
public class UserControl {

    @Autowired
    private UserService userService;

    @PostMapping("/new")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario guardarNuevo(@RequestBody Usuario usuario){
        return userService.saveNewUser(usuario);    
    }

    @GetMapping("/all")
    public List<Usuario> listaUsers(){
        return userService.getListUsers();
    }

    @GetMapping("/{id}")
    public Optional<Usuario> getUsuariosxID(@PathVariable("id") Integer id){
        return userService.getUsuario(id);
    }

    @GetMapping("/{email}/{password}")
    public Usuario validarInicio(@PathVariable("email") String email, @PathVariable("password") String password){
        return userService.validarLoggin(email, password);
    }

    @GetMapping("/emailexist/{email}")
    public boolean existenciaEmail(@PathVariable("email") String email){
        return userService.existeCorreo(email);
    }

    @DeleteMapping("/{Id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean eliminar(@PathVariable("Id") Integer usuarioId){
        return userService.deleteUser(usuarioId);
    }
    
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario actualizarUsuario(@RequestBody Usuario usuario){
        return userService.actualizarUser(usuario);
    }

    
}
