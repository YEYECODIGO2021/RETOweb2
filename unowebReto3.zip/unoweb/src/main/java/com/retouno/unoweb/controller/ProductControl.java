package com.retouno.unoweb.controller;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.model.Cosmeticos;
import com.retouno.unoweb.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@CrossOrigin("*")
@RequestMapping("/api/cosmetics")
public class ProductControl {

    @Autowired
    private ProductService productService;

@GetMapping("/all")
public List<Cosmeticos> getTodosProduct() {
    return productService.getProductos();
}

@GetMapping("/{referen}")
public Optional<Cosmeticos> getUnoProduct(@PathVariable("referen") String id){
    return productService.getUnProducto(id);
}
@PostMapping("/new")
@ResponseStatus(HttpStatus.CREATED)
public Cosmeticos guardarProduct(@RequestBody Cosmeticos nuevo) {  
    return productService.guadarNew(nuevo);
}
@DeleteMapping("/{referen}")
@ResponseStatus(HttpStatus.NO_CONTENT)
public boolean eliminarProduct(@PathVariable("referen") String id){
    return productService.deleteProduct(id);
}
@PutMapping("/update")
@ResponseStatus(HttpStatus.CREATED)
public Cosmeticos actualizarProduct(@RequestBody Cosmeticos modificar){
    return productService.actualizarProd(modificar);
}
}
