package com.retouno.unoweb.crud;

import com.retouno.unoweb.model.Cosmeticos;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductoCrud extends MongoRepository<Cosmeticos,String>{
    
}
