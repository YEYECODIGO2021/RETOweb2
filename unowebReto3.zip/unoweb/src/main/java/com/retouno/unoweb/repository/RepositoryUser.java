package com.retouno.unoweb.repository;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.crud.UserCrud;
import com.retouno.unoweb.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RepositoryUser {
    
    @Autowired
    UserCrud userCrud;


    public Usuario save(Usuario usuario){
        return userCrud.save(usuario);
    }
    
    public List<Usuario> getListUsuarios(){
        return (List<Usuario>)userCrud.findAll();
    }

    public Optional<Usuario>getUsuarioId(int id){
        return userCrud.findById(id);
    }
    
    public boolean siExisteEmail(String email){
        Optional<Usuario> user = userCrud.findByEmail(email);
        return !user.isEmpty();
    }

    public Optional<Usuario> validarRegistros(String email, String password){
        return userCrud.findByEmailAndPassword(email,password);
    }

    public void eliminarUser(Usuario usuarioDel){
        userCrud.delete(usuarioDel);
    }

    public Usuario actualizar(Usuario usuarioPut){
        return userCrud.save(usuarioPut);
    }

}