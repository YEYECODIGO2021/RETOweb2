package com.retouno.unoweb.repository;

import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.crud.UserCrud;
import com.retouno.unoweb.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author Yeison caballero
 */
@Repository
public class RepositoryUser {
    
    /**
     * conectoru usercrud
     */
    @Autowired
    UserCrud userCrud;

/**
 * metodo de guardar usuario
 * @param usuario
 * @return guarda un usuario
 */
    public Usuario save(Usuario usuario){
        return userCrud.save(usuario);
    }
    /**
     * Metodo obtener usuarios
     * @return lista de usuarios.
     */
    public List<Usuario> getListUsuarios(){
        return (List<Usuario>)userCrud.findAll();
    }
/**
 * metodo para traer un usuario x id
 * @param id
 * @return obtener un usuario x id
 */
    public Optional<Usuario>getUsuarioId(int id){
        return userCrud.findById(id);
    }
    /**
     * metodo valida email
     * @param email
     * @return boolean
     */
    public boolean siExisteEmail(String email){
        Optional<Usuario> user = userCrud.findByEmail(email);
        return !user.isEmpty();
    }
/**
 * metodo de index entre email y contraseña
 * @param email
 * @param password
 * @return usuario por contraseña y correo.
 */
    public Optional<Usuario> validarRegistros(String email, String password){
        return userCrud.findByEmailAndPassword(email,password);
    }
/**
 * metodo para eliminar uusuario
 * @param usuarioDel
 */
    public void eliminarUser(Usuario usuarioDel){
        userCrud.delete(usuarioDel);
    }
/**
 * metodo para actualizar usuario
 * @param usuarioPut
 * @return actualiza usuario.
 */
    public Usuario actualizar(Usuario usuarioPut){
        return userCrud.save(usuarioPut);
    }
    /**
     * metodo para encontrar el ultimo usuario.
     * @return el ultimo usuario.
     */
    public Optional<Usuario> finalUser(){
        return userCrud.findTopByOrderByIdDesc();
    }
/**
 * metodo para buscar fecha de cumpleaños.
 */
    public List<Usuario>buscarMes(String mes){
        return userCrud.findByMonthBirthtDay(mes);
    }
} 