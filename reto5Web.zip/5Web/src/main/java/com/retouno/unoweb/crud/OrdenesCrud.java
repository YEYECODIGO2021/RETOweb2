package com.retouno.unoweb.crud;

import java.util.List;
import java.util.Optional;

import com.retouno.unoweb.model.Ordenes;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface OrdenesCrud extends MongoRepository<Ordenes,Integer>{

    @Query("{'salesMan.zone':?0}")
    List<Ordenes>findByZone(final String country);

    @Query("{'status':?0}")
    List<Ordenes>findByStatus(final String status);

    Optional<Ordenes>findTopByOrderByIdDesc();
    
    
}
    