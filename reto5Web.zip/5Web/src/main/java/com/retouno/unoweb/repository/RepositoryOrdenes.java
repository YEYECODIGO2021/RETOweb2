package com.retouno.unoweb.repository;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import com.retouno.unoweb.crud.OrdenesCrud;
import com.retouno.unoweb.model.Ordenes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class RepositoryOrdenes {

    @Autowired
    private OrdenesCrud ordenesCrud;

    @Autowired
    private MongoTemplate mongoTemplate;

    public Ordenes guardarOrden(Ordenes orden){
        return ordenesCrud.save(orden);
    }

    public Optional<Ordenes> OrdenXid(int id){
        return ordenesCrud.findById(id);
    }

    public Optional<Ordenes> ultimaOrden(){
        return ordenesCrud.findTopByOrderByIdDesc();    
    }

    public List<Ordenes> getFullOrdenes(){
        return ordenesCrud.findAll();
}

public void updateOrden(Ordenes orden){
    ordenesCrud.save(orden);
}

public void deleteOrden(int id){
    ordenesCrud.deleteById(id);
}

public List<Ordenes>ordenesXZona(String country){
    return ordenesCrud.findByZone(country);
}

public List<Ordenes>ordenVendedorId(Integer id){
    Query query = new Query();
    Criteria datoCriteria = Criteria.where("salesMan.id").is(id);
    query.addCriteria(datoCriteria);
    List<Ordenes> listaOrdenesVendedor = mongoTemplate.find(query, Ordenes.class);
    return listaOrdenesVendedor;
}

public List<Ordenes>ordenVendedorEstado(String status, Integer id){
    Query query = new Query();
    Criteria busqueda = Criteria.where("salesMan.id").is(id).and("status").is(status);
    query.addCriteria(busqueda);
    List<Ordenes> datoCriteria2 = mongoTemplate.find(query, Ordenes.class);
return datoCriteria2;
}

public List<Ordenes>ordenVendedorFecha(String fecha,Integer id){
    DateTimeFormatter fFecha = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    Query query = new Query();
    Criteria buscar = Criteria.where("registerDay").gte(LocalDate.parse(fecha,fFecha).minusDays(1).atStartOfDay()).lt(LocalDate.parse(fecha, fFecha).plusDays(1).atStartOfDay()).and("salesMan.id").is(id);
    query.addCriteria(buscar);
    List<Ordenes> ordenesFecha = mongoTemplate.find(query, Ordenes.class);
    return ordenesFecha;
}
}