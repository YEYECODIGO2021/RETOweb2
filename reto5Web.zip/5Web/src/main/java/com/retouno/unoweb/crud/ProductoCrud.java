package com.retouno.unoweb.crud;


import java.util.List;
import com.retouno.unoweb.model.Cosmeticos;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;


public interface ProductoCrud extends MongoRepository<Cosmeticos,String>{

    List<Cosmeticos>findByPriceLessThanEqual(double precio);

    @Query("{'description':{'$regex':'?0','$options':'i'}}")
    List<Cosmeticos>findByDescriptionLike(String param);
}
